#!/bin/bash
# Starts the app on $PORT if set (e.g. Azure App Service), otherwise 8501.
PORT=${PORT:-8501}
streamlit run app.py --server.port="$PORT" --server.address=0.0.0.0
