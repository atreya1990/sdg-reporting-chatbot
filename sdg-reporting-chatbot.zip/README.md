# SDG Reporting Chatbot

A small Streamlit chat app that lets staff ask questions about system-wide reporting on the Sustainable Development Goals (SDGs). Questions go to an assistant hosted on **Azure AI Foundry**, and the app keeps the conversation context for the whole session.

> The assistant itself (its instructions and documents) lives in your Azure AI Foundry project, not in this repo. This repo is the chat front end.

## How it works

1. On first load, the app creates a conversation thread for the browser session.
2. Each question is added to the thread and the assistant is run on it.
3. The app waits for the run to finish, then shows the answer. Failures are shown in the chat instead of leaving a blank reply.

No keys or IDs are stored in the code. Everything comes from environment variables.

## Run it locally

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export AZURE_OPENAI_ENDPOINT="https://<your-resource>.openai.azure.com/"
export AZURE_OPENAI_API_KEY="<your-key>"
export ASSISTANT_ID="asst_..."

streamlit run app.py
```

See `.env.example` for all settings. If `AZURE_OPENAI_ENDPOINT` is not set, the app uses the plain OpenAI API with `OPENAI_API_KEY`.

## Deploy

`startup.sh` runs the app on `$PORT` (default 8501), which fits hosts such as Azure App Service. Set the same environment variables in the host's application settings.

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

The tests use a mocked client, so they need no keys and make no network calls.

## Tech stack

Python, Streamlit, Azure AI Foundry (Azure OpenAI Assistants API), `openai` SDK.

## Limitations

- Single assistant, no tool use or multi-step planning.
- No login. Put it behind your host's authentication before sharing it.
- Conversation history lives in the browser session only.

## Licence

MIT
