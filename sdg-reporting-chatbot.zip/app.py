"""Streamlit chat front end for an assistant hosted on Azure AI Foundry.

Configuration comes from environment variables (see .env.example), so no
keys or IDs live in the code. If AZURE_OPENAI_ENDPOINT is not set, the app
falls back to the plain OpenAI API.
"""
import os

import streamlit as st
from openai import AzureOpenAI, OpenAI

APP_TITLE = os.getenv("APP_TITLE", "Measuring System-Wide Contribution Towards the SDGs")
RUN_TIMEOUT_SECONDS = 120


def get_client():
    """Build the API client from environment variables."""
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    if endpoint:
        return AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-05-01-preview"),
        )
    return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def ask_assistant(client, thread_id, assistant_id, prompt):
    """Send one question to the assistant on an existing thread and return its answer."""
    client.beta.threads.messages.create(thread_id=thread_id, role="user", content=prompt)
    run = client.beta.threads.runs.create_and_poll(
        thread_id=thread_id,
        assistant_id=assistant_id,
        timeout=RUN_TIMEOUT_SECONDS,
    )
    if run.status != "completed":
        detail = getattr(run, "last_error", None)
        raise RuntimeError(f"Assistant run ended with status '{run.status}'. {detail or ''}".strip())

    messages = client.beta.threads.messages.list(thread_id=thread_id, order="desc", limit=1)
    parts = messages.data[0].content if messages.data else []
    return "\n\n".join(p.text.value for p in parts if getattr(p, "type", "") == "text") or "(No answer returned.)"


def main():
    st.set_page_config(page_title=APP_TITLE)
    st.header(APP_TITLE)

    assistant_id = os.getenv("ASSISTANT_ID")
    if not assistant_id:
        st.error("ASSISTANT_ID is not set. Copy .env.example, fill it in, and export the variables.")
        st.stop()

    client = get_client()

    # One conversation thread per browser session keeps context between questions.
    if "thread_id" not in st.session_state:
        st.session_state.thread_id = client.beta.threads.create().id
    if "messages" not in st.session_state:
        st.session_state.messages = [
            {"role": "assistant", "content": "Ask me a question about System-Wide reporting"}
        ]

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    if prompt := st.chat_input("Ask a question"):
        st.chat_message("user").markdown(prompt)
        st.session_state.messages.append({"role": "user", "content": prompt})

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    answer = ask_assistant(client, st.session_state.thread_id, assistant_id, prompt)
                except Exception as exc:  # show the problem instead of a blank reply
                    answer = f"Sorry, something went wrong: {exc}"
            st.markdown(answer)
        st.session_state.messages.append({"role": "assistant", "content": answer})


if __name__ == "__main__":
    main()
