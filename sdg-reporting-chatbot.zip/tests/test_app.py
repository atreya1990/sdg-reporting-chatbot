from types import SimpleNamespace
from unittest.mock import MagicMock

import app


def make_client(run_status="completed", answer="Hello from the assistant"):
    client = MagicMock()
    client.beta.threads.runs.create_and_poll.return_value = SimpleNamespace(status=run_status, last_error=None)
    text_part = SimpleNamespace(type="text", text=SimpleNamespace(value=answer))
    client.beta.threads.messages.list.return_value = SimpleNamespace(data=[SimpleNamespace(content=[text_part])])
    return client


def test_returns_assistant_text():
    client = make_client()
    assert app.ask_assistant(client, "thread_1", "asst_1", "What is SDG 1?") == "Hello from the assistant"
    client.beta.threads.messages.create.assert_called_once()


def test_failed_run_raises():
    client = make_client(run_status="failed")
    try:
        app.ask_assistant(client, "thread_1", "asst_1", "hi")
    except RuntimeError as exc:
        assert "failed" in str(exc)
    else:
        raise AssertionError("expected RuntimeError")


def test_uses_azure_client_when_endpoint_set(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://example.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "test")
    assert type(app.get_client()).__name__ == "AzureOpenAI"


def test_falls_back_to_openai(monkeypatch):
    monkeypatch.delenv("AZURE_OPENAI_ENDPOINT", raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "test")
    assert type(app.get_client()).__name__ == "OpenAI"
